# Changelog

## 0.1.0

- Initial standalone XPortalNetworks map-pin integration.
